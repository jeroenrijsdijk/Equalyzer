"""Tests for parking.py. Run from the plugin folder:

    python -m unittest discover -s tests -v
"""

import math
import unittest

from shapely import affinity
from shapely.geometry import Polygon

import fake_qgis

fake_qgis.install()

from equal_parts import split_into_equal_parts  # noqa: E402
from fake_qgis import Geom, edge_angles  # noqa: E402
from parking import (  # noqa: E402
    AMBIGUOUS, PARALLEL, PERPENDICULAR, axis_angle_degrees, choose_count,
    convex_hull, end_slant, min_width_axis, plan_bays, plan_strip, strip_axis,
)


def parallelogram(kerb, depth, slant, rotate=0.0, slant_far=None):
    """Strip with kerb sides of `kerb` m whose ends lean `slant` degrees from
    square; `slant_far` gives the far end its own slant."""
    near = depth * math.tan(math.radians(slant))
    far = near if slant_far is None else depth * math.tan(math.radians(slant_far))
    shape = Polygon([(0, 0), (kerb, 0), (kerb + far, depth), (near, depth)])
    return affinity.rotate(shape, rotate, origin=(0, 0))


def strip(length, depth, angle):
    """A length x depth rectangle rotated by angle degrees about the origin."""
    return affinity.rotate(Polygon([(0, 0), (length, 0), (length, depth), (0, depth)]),
                           angle, origin=(0, 0))


class Counting(unittest.TestCase):

    def test_prefers_roomy_bays_over_bays_under_the_minimum(self):
        # 17.86 m is 3.57 bays of 5 m: four would be 4.47 m, three are 5.95 m
        count, ok = choose_count(17.86, 5.0, 4.80, 7.5)
        self.assertEqual((count, ok), (3, True))

    def test_exact_multiple(self):
        self.assertEqual(choose_count(20.0, 5.0, 4.80, 7.5), (4, True))

    def test_on_the_minimum_is_still_acceptable(self):
        self.assertEqual(choose_count(14.40, 5.0, 4.80, 7.5), (3, True))

    def test_just_under_the_minimum_rounds_down(self):
        self.assertEqual(choose_count(14.20, 5.0, 4.80, 7.5), (2, True))

    def test_never_collapses_into_one_huge_bay(self):
        # 9.5 m: one bay of 9.5 breaks the maximum, two of 4.75 break the
        # minimum; the size closest to nominal wins and the caller is told
        self.assertEqual(choose_count(9.5, 5.0, 4.80, 7.5), (2, False))

    def test_shorter_than_one_bay(self):
        self.assertEqual(choose_count(3.0, 5.0, 4.80, 7.5), (1, False))


class Planning(unittest.TestCase):

    def test_orientation_follows_the_depth(self):
        self.assertEqual(plan_bays(40.0, 2.5).orientation, PARALLEL)
        self.assertEqual(plan_bays(40.0, 5.0).orientation, PERPENDICULAR)
        self.assertEqual(plan_bays(40.0, 2.05).orientation, PARALLEL)     # -18 %
        self.assertEqual(plan_bays(40.0, 1.9).orientation, AMBIGUOUS)     # too shallow
        self.assertEqual(plan_bays(60.0, 3.5).orientation, AMBIGUOUS)     # in between

    def test_counts(self):
        cases = [
            (40.2, 2.4, 8), (92.4, 5.1, 37), (17.5, 5.0, 7), (17.86, 2.4, 3),
            (17.0, 5.0, 7),    # 2.43 m, just above the 2.40 minimum
            (16.5, 5.0, 6),    # 7 would be 2.36 m, under the minimum
        ]
        for length, depth, expected in cases:
            with self.subTest(length=length, depth=depth):
                self.assertEqual(plan_bays(length, depth).count, expected)

    def test_override_beats_inference(self):
        plan = plan_bays(60.0, 3.5, orientation=PERPENDICULAR)
        self.assertEqual(plan.orientation, PERPENDICULAR)
        self.assertEqual(plan.count, 24)

    def test_warnings(self):
        self.assertTrue(any("curved" in w for w in plan_bays(40.0, 2.4, fit=0.72).warnings))
        self.assertTrue(any("only one bay" in w for w in plan_bays(5.2, 2.5).warnings))
        self.assertTrue(any("instead of the nominal" in w for w in plan_bays(17.86, 2.4).warnings))
        self.assertEqual(plan_bays(20.0, 2.5).warnings, [])


class Axis(unittest.TestCase):

    def test_hull_of_a_square_with_interior_points(self):
        hull = convex_hull([(0, 0), (4, 0), (4, 4), (0, 4), (2, 2), (1, 3)])
        self.assertEqual(len(hull), 4)

    def test_min_width_axis_finds_the_long_side(self):
        for angle in (0, 23, 67, 112, 160):
            with self.subTest(angle=angle):
                shape = strip(40.0, 2.5, angle)
                along, across, length, width, _ = min_width_axis(convex_hull(shape.exterior.coords))
                self.assertAlmostEqual(length, 40.0, places=6)
                self.assertAlmostEqual(width, 2.5, places=6)
                self.assertAlmostEqual(math.degrees(math.atan2(along[1], along[0])) % 180,
                                       angle % 180, places=6)

    def test_strip_axis_is_square_to_the_strip(self):
        for angle in (0, 23, 67, 112):
            with self.subTest(angle=angle):
                cut_points, length, depth, fit = strip_axis(Geom(strip(40.0, 2.5, angle)))
                self.assertAlmostEqual(length, 40.0, places=6)
                self.assertAlmostEqual(depth, 2.5, places=6)
                self.assertAlmostEqual(fit, 1.0, places=6)
                self.assertAlmostEqual(axis_angle_degrees(cut_points) % 180, (angle + 90) % 180, places=6)

    def test_skewed_parallelogram_still_gets_square_bays(self):
        # long sides at 67 degrees, end edges skewed by 28 degrees
        u = (math.cos(math.radians(67)), math.sin(math.radians(67)))
        end = 67 - 90 + 28
        v = (math.cos(math.radians(end)) * 8.5, math.sin(math.radians(end)) * 8.5)
        shape = Polygon([(0, 0), (u[0] * 45, u[1] * 45),
                         (u[0] * 45 + v[0], u[1] * 45 + v[1]), (v[0], v[1])])
        cut_points, length, depth, fit = strip_axis(Geom(shape))
        self.assertAlmostEqual(axis_angle_degrees(cut_points) % 180, 157.0, places=6)
        result = split_into_equal_parts(Geom(shape), 9, axis_angle_degrees(cut_points),
                                        lambda g: g.area())
        for part in result.parts[1:-1]:             # end pieces inherit the skew
            self.assertEqual(edge_angles(part), [67.0, 157.0])

    def test_usable_length_ignores_the_slant(self):
        # 15 m of kerb with ends leaning 25 degrees: the full extent along the
        # kerb is 17.33 m, the usable length along the middle is 15 m
        cut_points, length, depth, fit = strip_axis(Geom(parallelogram(15, 5, 25, rotate=8)))
        self.assertAlmostEqual(length, 15.0, places=6)
        self.assertAlmostEqual(depth, 5.0, places=6)

    def test_measure_callable_is_used_for_sizes(self):
        scale = 111320.0
        shape = affinity.scale(strip(40.0, 2.5, 30), 1 / scale, 1 / scale, origin=(0, 0))
        def metres(a, b):
            return math.hypot(b.x() - a.x(), b.y() - a.y()) * scale
        _, length, depth, _ = strip_axis(Geom(shape), metres)
        self.assertAlmostEqual(length, 40.0, places=6)
        self.assertAlmostEqual(depth, 2.5, places=6)


class SlantedEnds(unittest.TestCase):
    """Perpendicular bays follow the ends when the ends are parallel."""

    def axes(self, shape):
        hull = convex_hull(shape.exterior.coords)
        along, across, _, depth, _ = min_width_axis(hull)
        return hull, along, across, depth

    def test_square_ends_are_left_alone(self):
        for shape in (strip(17.5, 5.0, 23), parallelogram(17.5, 5.0, 1.0)):
            with self.subTest(shape=shape.wkt[:40]):
                self.assertEqual(end_slant(*self.axes(shape)), (None, None))

    def test_parallel_slanted_ends_are_found(self):
        for slant in (10, 30, -30, 45):
            with self.subTest(slant=slant):
                found, note = end_slant(*self.axes(parallelogram(20, 5, slant, rotate=37)))
                self.assertAlmostEqual(abs(found), abs(slant), places=6)
                self.assertIsNone(note)

    def test_ends_that_are_not_parallel_are_reported(self):
        found, note = end_slant(*self.axes(parallelogram(20, 5, 0, slant_far=30)))
        self.assertIsNone(found)
        self.assertIn("not parallel", note)

    def test_rounded_ends_are_not_followed(self):
        rounded = strip(20, 5, 0).buffer(-1.0).buffer(1.0, quad_segs=8)
        self.assertEqual(end_slant(*self.axes(rounded)), (None, None))

    def test_parallelogram_becomes_identical_slanted_bays(self):
        # 20 m of kerb, 5 m deep, ends 30 degrees from square. Square to the
        # cuts the strip is 20 x cos 30 = 17.32 m: 7 bays of 2.47 m, each
        # 5.77 m long along the cut.
        shape = parallelogram(20, 5, 30, rotate=-15)
        strip_plan = plan_strip(Geom(shape))
        plan = strip_plan.plan
        self.assertEqual((plan.orientation, plan.count), (PERPENDICULAR, 7))
        self.assertAlmostEqual(abs(plan.slant), 30.0, places=6)
        self.assertAlmostEqual(plan.actual, 20 * math.cos(math.radians(30)) / 7, places=6)
        self.assertAlmostEqual(plan.bay_depth, 5 / math.cos(math.radians(30)), places=6)
        self.assertEqual(plan.warnings, [])
        self.assertIn("slanted ends", plan.describe())

        parts = split_into_equal_parts(Geom(shape), plan.count,
                                       axis_angle_degrees(strip_plan.cut_points),
                                       lambda g: g.area()).parts
        self.assertEqual(len(parts), 7)
        kerb, ends = (-15) % 180, (-15 + 60) % 180
        for part in parts:
            self.assertAlmostEqual(part.area(), 100.0 / 7, places=6)
            self.assertEqual(len(part.g.exterior.coords), 5)      # four corners
            self.assertEqual(edge_angles(part), sorted([float(kerb), float(ends)]))

    def test_rectangles_are_unchanged(self):
        strip_plan = plan_strip(Geom(strip(17.5, 5.0, 23)))
        self.assertEqual(strip_plan.plan.count, 7)
        self.assertEqual(strip_plan.plan.slant, 0.0)
        self.assertAlmostEqual(axis_angle_degrees(strip_plan.cut_points) % 180, 113.0, places=6)

    def test_parallel_bays_stay_square_to_the_kerb(self):
        strip_plan = plan_strip(Geom(parallelogram(20, 2.4, 30)))
        self.assertEqual(strip_plan.plan.orientation, PARALLEL)
        self.assertEqual(strip_plan.plan.slant, 0.0)
        self.assertAlmostEqual(axis_angle_degrees(strip_plan.cut_points) % 180, 90.0, places=6)

    def test_non_parallel_ends_are_cut_square_and_flagged(self):
        strip_plan = plan_strip(Geom(parallelogram(20, 5, 0, slant_far=30)))
        self.assertEqual(strip_plan.plan.slant, 0.0)
        self.assertAlmostEqual(axis_angle_degrees(strip_plan.cut_points) % 180, 90.0, places=6)
        self.assertTrue(any("not parallel" in w for w in strip_plan.plan.warnings))

    def test_forced_perpendicular_also_follows_the_ends(self):
        # 3.5 m deep is ambiguous; forcing perpendicular still follows the ends
        strip_plan = plan_strip(Geom(parallelogram(20, 3.5, 20)), orientation=PERPENDICULAR)
        self.assertAlmostEqual(abs(strip_plan.plan.slant), 20.0, places=6)


class GeographicCrs(unittest.TestCase):
    """Why the plugin works in a metric frame for geographic layers."""

    KX = 111320.0 * math.cos(math.radians(52.0))   # metres per degree of longitude
    KY = 110574.0                                   # metres per degree of latitude

    def test_degree_space_skews_the_perpendicular(self):
        rect = strip(17.5, 5.0, 67)
        in_degrees = affinity.affine_transform(rect, [1 / self.KX, 0, 0, 1 / self.KY, 4.5, 52.0])
        cut_points, _, _, _ = strip_axis(Geom(in_degrees))
        deg_angle = axis_angle_degrees(cut_points)
        on_ground = math.degrees(math.atan2(
            math.sin(math.radians(deg_angle)) * self.KY,
            math.cos(math.radians(deg_angle)) * self.KX)) % 180
        self.assertGreater(abs(on_ground - 157.0), 20.0)    # badly off

    def test_metric_frame_restores_the_right_angle(self):
        rect = strip(17.5, 5.0, 67)
        in_degrees = affinity.affine_transform(rect, [1 / self.KX, 0, 0, 1 / self.KY, 4.5, 52.0])
        back = affinity.affine_transform(in_degrees, [self.KX, 0, 0, self.KY, 0, 0])
        cut_points, length, depth, _ = strip_axis(Geom(back))
        self.assertAlmostEqual(axis_angle_degrees(cut_points) % 180, 157.0, places=6)
        self.assertEqual(plan_bays(length, depth).count, 7)


if __name__ == "__main__":
    unittest.main()
