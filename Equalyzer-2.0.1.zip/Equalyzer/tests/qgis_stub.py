"""Stub enough of qgis.core / qgis.gui / qgis.PyQt to import polygon_splitter.py.

Builds on fake_qgis (shapely-backed geometry) and needs PyQt6 or PyQt5 for the
Qt classes the module references at import time. Used by test_engine.py.

Coordinate reference systems are modelled around 52 degrees north, which is
where the difference matters for this plugin:

  EPSG:28992  RD New, coordinates are ground metres
  EPSG:326xx  UTM, ground metres
  EPSG:4326   degrees; one degree of longitude is 62% of one of latitude
  EPSG:3857   Web Mercator, "metres" stretched by 1/cos(52 deg)

Transforms between them are the corresponding affine maps through a common
ground-metre frame, which is exact enough for shapes a few hundred metres
across and keeps the tests independent of PROJ.
"""
import enum
import importlib
import math
import os
import sys
import types

from shapely import affinity
from shapely.geometry import MultiPolygon, Polygon

try:
    import PyQt6.QtCore as _QtCore
    import PyQt6.QtGui as _QtGui
    import PyQt6.QtWidgets as _QtWidgets
except ImportError:                                   # pragma: no cover
    import PyQt5.QtCore as _QtCore
    import PyQt5.QtGui as _QtGui
    import PyQt5.QtWidgets as _QtWidgets

import fake_qgis  # noqa: E402

fake_qgis.install()
from fake_qgis import Geom, Pt, Rect, WkbTypes  # noqa: E402

LAT0, LON0 = 52.0, 4.5
KX = 111320.0 * math.cos(math.radians(LAT0))    # ground metres per degree of longitude
KY = 110574.0                                    # ground metres per degree of latitude
MERC = math.cos(math.radians(LAT0))              # ground metres per Web Mercator metre


# ---- CRS model --------------------------------------------------------------

def _to_ground(authid):
    """(a, b, d, e, xoff, yoff) mapping this CRS to ground metres."""
    if authid == "EPSG:4326":
        return (KX, 0, 0, KY, -LON0 * KX, -LAT0 * KY)
    if authid == "EPSG:3857":
        return (MERC, 0, 0, MERC, 0, 0)
    return (1, 0, 0, 1, 0, 0)                   # RD, UTM: already ground metres


def _from_ground(authid):
    a, _, _, e, xo, yo = _to_ground(authid)
    return (1 / a, 0, 0, 1 / e, -xo / a, -yo / e)


def _compose(first, second):
    a1, _, _, e1, x1, y1 = first
    a2, _, _, e2, x2, y2 = second
    return (a2 * a1, 0, 0, e2 * e1, a2 * x1 + x2, e2 * y1 + y2)


# ---- extend the fake geometry with what the plugin needs ----------------------

def _from_polygon_xy(rings):
    shell = [(p.x(), p.y()) for p in rings[0]]
    holes = [[(p.x(), p.y()) for p in r] for r in rings[1:]]
    return Geom(Polygon(shell, holes))


def _from_polyline_xy(points):
    from shapely.geometry import LineString
    return Geom(LineString([(p.x(), p.y()) for p in points]))


def _from_point_xy(point):
    from shapely.geometry import Point
    return Geom(Point(point.x(), point.y()))


def _transform(self, t):
    self.g = affinity.affine_transform(self.g, list(t.matrix))
    return 0


def _coerce_to_type(self, wkb):
    polys = list(self.g.geoms) if self.g.geom_type == "MultiPolygon" else [self.g]
    if wkb == 6:
        return [Geom(MultiPolygon(polys))]
    return [Geom(p) for p in polys]


def _from_multipolygon_xy(polygons):
    return Geom(MultiPolygon([_from_polygon_xy(rings).g for rings in polygons]))


Geom.fromPolygonXY = staticmethod(_from_polygon_xy)
Geom.fromMultiPolygonXY = staticmethod(_from_multipolygon_xy)
Geom.fromPolylineXY = staticmethod(_from_polyline_xy)
Geom.fromPointXY = staticmethod(_from_point_xy)
Geom.type = lambda self: 2 if self.g.geom_type in ("Polygon", "MultiPolygon") else 0
Geom.buffer = lambda self, d, s=0: Geom(self.g.buffer(d))
Geom.constGet = lambda self: [Geom(p) for p in getattr(self.g, "geoms", [self.g])]
Geom.combine = lambda self, o: Geom(self.g.union(o.g))
Geom.centroid = lambda self: types.SimpleNamespace(
    asPoint=lambda: Pt(self.g.centroid.x, self.g.centroid.y))
Geom.transform = _transform
Geom.length = lambda self: self.g.length
Geom.intersects = lambda self, o: self.g.intersects(o.g)
Geom.contains = lambda self, o: self.g.contains(o.g)
Geom.coerceToType = _coerce_to_type
Geom.asWkt = lambda self, *a: self.g.wkt


def _grow(self, delta):
    x0, y0, x1, y1 = self.b
    self.b = (x0 - delta, y0 - delta, x1 + delta, y1 + delta)


Rect.grow = _grow


# ---- stub qgis modules ------------------------------------------------------

def mk(name):
    m = types.ModuleType(name)
    sys.modules[name] = m
    return m


qgis = mk("qgis")
pyqt = mk("qgis.PyQt")
qgis.PyQt = pyqt
for sub, real in (("QtCore", _QtCore), ("QtGui", _QtGui), ("QtWidgets", _QtWidgets)):
    m = mk(f"qgis.PyQt.{sub}")
    for n in dir(real):
        setattr(m, n, getattr(real, n))
    setattr(pyqt, sub, m)

core = mk("qgis.core")


class Qgis:
    QGIS_VERSION_INT = 40200
    MessageLevel = enum.IntEnum("MessageLevel", ["Info", "Warning", "Critical", "Success"])
    GeometryOperationResult = enum.IntEnum("GeometryOperationResult", {"Success": 0})
    AreaUnit = enum.IntEnum("AreaUnit", ["SquareMeters", "SquareFeet", "SquareDegrees"])
    DistanceUnit = enum.IntEnum("DistanceUnit", ["Meters", "Feet", "Degrees"])
    WkbType = enum.IntEnum("WkbType", {"Polygon": 3, "MultiPolygon": 6, "GeometryCollection": 7})
    GeometryType = enum.IntEnum("GeometryType", {"Point": 0, "Line": 1, "Polygon": 2})
    LayerType = enum.IntEnum("LayerType", {"Vector": 0, "Raster": 1})
    SnappingMode = enum.IntEnum("SnappingMode", ["AdvancedConfiguration", "ActiveLayer"])
    SnappingType = enum.IntEnum("SnappingType", ["Vertex", "Segment"])
    MapToolUnit = enum.IntEnum("MapToolUnit", ["Pixels"])


class _Stub:
    def __init__(self, *a, **k):
        pass

    def __getattr__(self, item):
        return _Stub()

    def __call__(self, *a, **k):
        return _Stub()


class QgsCoordinateReferenceSystem:
    def __init__(self, authid="EPSG:28992"):
        self._id = authid

    def __eq__(self, other):
        return isinstance(other, QgsCoordinateReferenceSystem) and other._id == self._id

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(self._id)

    def isGeographic(self):
        return self._id == "EPSG:4326"

    def authid(self):
        return self._id

    def mapUnits(self):
        return Qgis.DistanceUnit.Degrees if self.isGeographic() else Qgis.DistanceUnit.Meters

    def isValid(self):
        return True

    def ellipsoidAcronym(self):
        return "EPSG:7004" if self._id == "EPSG:28992" else "EPSG:7030"


class QgsCoordinateTransform:
    def __init__(self, source, dest, ctx):
        self.matrix = _compose(_to_ground(source.authid()), _from_ground(dest.authid()))

    def transform(self, p):
        a, _, _, e, xo, yo = self.matrix
        return Pt(a * p.x() + xo, e * p.y() + yo)


class QgsProject:
    ellipsoid_setting = "NONE"

    class _Inst:
        def ellipsoid(self):
            return QgsProject.ellipsoid_setting

        def transformContext(self):
            return None

        def areaUnits(self):
            return Qgis.AreaUnit.SquareMeters

        def mapLayers(self):
            return {}

        def layerTreeRoot(self):
            return types.SimpleNamespace(findLayers=lambda: [])

        def snappingConfig(self):
            return QgsSnappingConfig()

    @staticmethod
    def instance():
        return QgsProject._Inst()


class QgsDistanceArea:
    """Planar measurement in CRS units, or ground metres once an ellipsoid is set."""

    def __init__(self):
        self.crs = QgsCoordinateReferenceSystem("EPSG:4326")
        self.ellipsoid = "NONE"

    def setSourceCrs(self, crs, ctx):
        self.crs = crs

    def setEllipsoid(self, name):
        self.ellipsoid = name
        return True

    def willUseEllipsoid(self):
        return bool(self.ellipsoid) and self.ellipsoid.upper() != "NONE"

    def _scale(self):
        a, _, _, e, _, _ = _to_ground(self.crs.authid())
        return (a, e) if self.willUseEllipsoid() else (1.0, 1.0)

    def measureArea(self, g):
        a, e = self._scale()
        return g.area() * a * e

    def measureLine(self, p, q):
        a, e = self._scale()
        return math.hypot((q.x() - p.x()) * a, (q.y() - p.y()) * e)

    def lengthUnits(self):
        return Qgis.DistanceUnit.Meters if self.willUseEllipsoid() else self.crs.mapUnits()


class QgsField:
    def __init__(self, name, type_=None):
        self._n = name

    def name(self):
        return self._n

    def setName(self, n):
        self._n = n


class QgsFeature:
    def __init__(self, fields=None):
        self._attrs = {}
        self._g = None

    def setGeometry(self, g):
        self._g = g

    def geometry(self):
        return self._g

    def setAttribute(self, key, value):
        self._attrs[key] = value

    def attribute(self, key):
        return self._attrs.get(key)


class QgsSnappingConfig:
    """Records what was set, so tests can see whether it is put back."""

    class IndividualLayerSettings:
        def __init__(self, *args):
            self.args = args

    def __init__(self, other=None):
        self.state = dict(other.state) if other is not None else {"mode": None, "enabled": False}

    def setMode(self, mode):
        self.state["mode"] = mode

    def setEnabled(self, enabled):
        self.state["enabled"] = enabled

    def setIndividualLayerSettings(self, layer, settings):
        self.state[layer] = settings


class QgsPointLocator:
    class Match:
        def isValid(self):
            return False


core.QgsGeometry, core.QgsPointXY, core.QgsRectangle, core.QgsWkbTypes = Geom, Pt, Rect, WkbTypes
for obj in (Qgis, QgsProject, QgsDistanceArea, QgsCoordinateReferenceSystem, QgsCoordinateTransform,
            QgsField, QgsFeature, QgsSnappingConfig, QgsPointLocator):
    setattr(core, obj.__name__, obj)
core.QgsUnitTypes = type("QgsUnitTypes", (), {
    "toAbbreviatedString": staticmethod(lambda u: "m²"),
    "fromUnitToUnitFactor": staticmethod(lambda a, b: 1.0)})
core.QgsMessageLog = type("QgsMessageLog", (), {"logMessage": staticmethod(lambda *a, **k: None)})
for n in ("QgsVectorLayer QgsVectorLayerSimpleLabeling QgsPalLayerSettings QgsTextFormat "
          "QgsPoint QgsTolerance QgsMapLayer QgsVectorFileWriter QgsFeatureRequest").split():
    setattr(core, n, type(n, (_Stub,), {}))
core.QgsVectorFileWriter.WriterError = enum.IntEnum("WriterError", ["NoError"])
qgis.core = core


class QgsMapToolEmitPoint:
    def __init__(self, canvas):
        pass

    def activate(self):
        pass

    def deactivate(self):
        pass

    def toMapCoordinates(self, pos):
        return pos


gui = mk("qgis.gui")
gui.QgsMapToolEmitPoint = QgsMapToolEmitPoint
gui.QgsRubberBand = type("QgsRubberBand", (_Stub,), {})
gui.QgsSnapIndicator = type("QgsSnapIndicator", (_Stub,), {})
qgis.gui = gui
utils = mk("qgis.utils")
utils.iface = _Stub()
qgis.utils = utils

# the plugin package is the parent of the tests dir; import it under its folder name
_plugin_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_parent = os.path.dirname(_plugin_dir)
if _parent not in sys.path:
    sys.path.insert(0, _parent)
plugin = importlib.import_module(os.path.basename(_plugin_dir) + ".polygon_splitter")


# ---- fakes for layers, features, canvas -------------------------------------

class Layer:
    """Vector layer with an edit buffer that behaves like QGIS's for our calls."""

    def __init__(self, authid, wkb_type=6, features=(), editable=False, accept_adds=True):
        self._crs = QgsCoordinateReferenceSystem(authid)
        self._wkb = wkb_type
        self.features = {f.id(): f for f in features}
        self.editable = editable
        self.accept_adds = accept_adds
        self.log = []
        self._command = None
        self._next_id = 1000

    def crs(self):
        return self._crs

    def id(self):
        return "layer0"

    def name(self):
        return "strips"

    def fields(self):
        width = max((len(f._attrs) for f in self.features.values() if hasattr(f, "_attrs")), default=0)
        return [QgsField(f"field{i}") for i in range(width)]

    def wkbType(self):
        return self._wkb

    def primaryKeyAttributes(self):
        return []

    def getFeatures(self, request=None):
        return list(self.features.values())

    def selectByIds(self, ids):
        self.selected = list(ids)

    def extent(self):
        geoms = [f.geometry() for f in self.features.values()]
        if not geoms:
            return Rect(0, 0, 1, 1)
        boxes = [g.boundingBox() for g in geoms]
        return Rect(min(b.xMinimum() for b in boxes), min(b.yMinimum() for b in boxes),
                    max(b.xMaximum() for b in boxes), max(b.yMaximum() for b in boxes))

    # editing
    def isEditable(self):
        return self.editable

    def startEditing(self):
        self.log.append("startEditing")
        self.editable = True
        return True

    def beginEditCommand(self, text):
        self.log.append("begin")
        self._command = dict(self.features)

    def endEditCommand(self):
        self.log.append("end")
        self._command = None

    def destroyEditCommand(self):
        self.log.append("destroy")
        self.features = self._command
        self._command = None

    def addFeatures(self, feats):
        self.log.append(f"add {len(feats)}")
        for f in feats:
            self.features[self._next_id] = f
            self._next_id += 1
        return self.accept_adds

    def deleteFeatures(self, ids):
        self.log.append(f"delete {sorted(ids)}")
        for i in ids:
            self.features.pop(i, None)
        return True

    def rollBack(self):
        self.log.append("rollBack")
        self.editable = False

    def commitChanges(self, *a):
        self.log.append("commit")
        return True


class Feature:
    def __init__(self, fid, geom, attrs=None):
        self._id, self._g = fid, geom
        self._attrs = list(attrs or [])

    def id(self):
        return self._id

    def geometry(self):
        return self._g

    def attribute(self, index):
        return self._attrs[index]


class Canvas:
    """Just enough of QgsMapCanvas for the map tools."""

    def __init__(self, previous_tool=None):
        self.tool = previous_tool
        self.snapping = types.SimpleNamespace(
            cfg=QgsSnappingConfig(),
            config=lambda: self.snapping.cfg,
            setConfig=lambda c: setattr(self.snapping, "cfg", c),
            snapToMap=lambda p: types.SimpleNamespace(isValid=lambda: False, point=lambda: p),
        )

    def mapTool(self):
        return self.tool

    def setMapTool(self, tool):
        if self.tool is not None and hasattr(self.tool, "deactivate"):
            self.tool.deactivate()
        self.tool = tool
        if hasattr(tool, "activate"):
            tool.activate()

    def unsetMapTool(self, tool):
        if self.tool is tool:
            tool.deactivate()
            self.tool = None

    def snappingUtils(self):
        return self.snapping


def click(point, right=False):
    """A mouse release event at `point` (map coordinates, see toMapCoordinates)."""
    button = _QtCore.Qt.MouseButton.RightButton if right else _QtCore.Qt.MouseButton.LeftButton
    return types.SimpleNamespace(button=lambda: button, pos=lambda: point)


def strip(length, depth, angle, offset=(0, 0)):
    """length x depth rectangle in ground metres, rotated and moved."""
    p = Polygon([(0, 0), (length, 0), (length, depth), (0, depth)])
    p = affinity.rotate(p, angle, origin=(0, 0))
    return Geom(affinity.translate(p, *offset))


def in_crs(geom, authid):
    """A ground-metre geometry expressed in another CRS of the model."""
    g = Geom(geom)
    g.transform(QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:28992"),
                                       QgsCoordinateReferenceSystem(authid), None))
    return g


def to_ground(geom, authid):
    g = Geom(geom)
    g.transform(QgsCoordinateTransform(QgsCoordinateReferenceSystem(authid),
                                       QgsCoordinateReferenceSystem("EPSG:28992"), None))
    return g


def point_in_crs(x, y, authid):
    t = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:28992"),
                               QgsCoordinateReferenceSystem(authid), None)
    return t.transform(Pt(x, y))
