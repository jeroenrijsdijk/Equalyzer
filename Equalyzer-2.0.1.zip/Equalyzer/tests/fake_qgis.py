"""A shapely-backed stand-in for the few QgsGeometry calls the pure engines use.

Installs fake `qgis` and `qgis.core` modules so equal_parts.py and parking.py
import without QGIS, and provides Geom/Pt/Rect that behave like QgsGeometry,
QgsPointXY and QgsRectangle for the operations those modules perform.

Conventions copied from QGIS: rotate() is clockwise-positive; QgsRectangle is
(xmin, ymin, xmax, ymax).
"""

import math
import os
import sys
import types

from shapely import affinity
from shapely.geometry import Polygon, box
from shapely.ops import unary_union

PLUGIN_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class Pt:
    def __init__(self, x, y):
        self._x, self._y = x, y

    def x(self):
        return self._x

    def y(self):
        return self._y


class Rect:
    def __init__(self, x0, y0, x1, y1):
        self.b = (x0, y0, x1, y1)

    def xMinimum(self):
        return self.b[0]

    def yMinimum(self):
        return self.b[1]

    def xMaximum(self):
        return self.b[2]

    def yMaximum(self):
        return self.b[3]

    def width(self):
        return self.b[2] - self.b[0]

    def height(self):
        return self.b[3] - self.b[1]

    def center(self):
        return Pt((self.b[0] + self.b[2]) / 2, (self.b[1] + self.b[3]) / 2)


class Geom:
    def __init__(self, other=None):
        if other is None:
            self.g = Polygon()
        elif isinstance(other, Geom):
            self.g = other.g
        else:
            self.g = other

    @staticmethod
    def fromRect(rect):
        return Geom(box(*rect.b))

    @staticmethod
    def unaryUnion(geoms):
        return Geom(unary_union([g.g for g in geoms]))

    def isEmpty(self):
        return self.g.is_empty

    def isGeosValid(self):
        return self.g.is_valid

    def makeValid(self):
        return Geom(self.g.buffer(0))

    def isMultipart(self):
        return self.g.geom_type == "MultiPolygon"

    def area(self):
        return self.g.area

    def boundingBox(self):
        return Rect(*self.g.bounds) if not self.g.is_empty else Rect(0, 0, 0, 0)

    def wkbType(self):
        return {"Polygon": 3, "MultiPolygon": 6, "GeometryCollection": 7}.get(self.g.geom_type, 0)

    def asPolygon(self):
        return ([[Pt(*c) for c in self.g.exterior.coords]]
                + [[Pt(*c) for c in r.coords] for r in self.g.interiors])

    def asMultiPolygon(self):
        return [Geom(p).asPolygon() for p in self.g.geoms]

    def asGeometryCollection(self):
        return [Geom(p) for p in self.g.geoms]

    def rotate(self, angle_deg, center):
        # QGIS rotates clockwise for positive angles; shapely counter-clockwise
        self.g = affinity.rotate(self.g, -angle_deg, origin=(center.x(), center.y()))
        return 0

    def intersection(self, other):
        return Geom(self.g.intersection(other.g))


class WkbTypes:
    class Type:
        Polygon, MultiPolygon, GeometryCollection = 3, 6, 7

    @staticmethod
    def flatType(t):
        return t


def install():
    """Register the fake qgis modules and put the plugin dir on sys.path."""
    core = types.ModuleType("qgis.core")
    core.QgsGeometry, core.QgsPointXY, core.QgsRectangle, core.QgsWkbTypes = Geom, Pt, Rect, WkbTypes
    qgis = sys.modules.get("qgis") or types.ModuleType("qgis")
    qgis.core = core
    sys.modules["qgis"] = qgis
    sys.modules["qgis.core"] = core
    if PLUGIN_DIR not in sys.path:
        sys.path.insert(0, PLUGIN_DIR)


def edge_angles(geom, digits=1):
    """Set of edge directions (degrees mod 180) of a polygon, for shape checks."""
    coords = list(geom.g.exterior.coords)
    return sorted({round(math.degrees(math.atan2(b[1] - a[1], b[0] - a[0])) % 180, digits)
                   for a, b in zip(coords, coords[1:])})
