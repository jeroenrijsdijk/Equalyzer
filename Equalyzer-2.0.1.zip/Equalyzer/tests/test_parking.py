"""Tests for parking.py. Run from the plugin folder:

    python -m unittest discover -s tests -v
"""

import math
import unittest

from shapely import affinity
from shapely.geometry import Polygon

import fake_qgis

fake_qgis.install()

from equal_parts import split_into_equal_parts  # noqa: E402
from fake_qgis import Geom, edge_angles  # noqa: E402
from parking import (  # noqa: E402
    AMBIGUOUS, PARALLEL, PERPENDICULAR, axis_angle_degrees, choose_count,
    convex_hull, min_width_axis, plan_bays, strip_axis,
)


def strip(length, depth, angle):
    """A length x depth rectangle rotated by angle degrees about the origin."""
    return affinity.rotate(Polygon([(0, 0), (length, 0), (length, depth), (0, depth)]),
                           angle, origin=(0, 0))


class Counting(unittest.TestCase):

    def test_prefers_roomy_bays_over_bays_under_the_minimum(self):
        # 17.86 m is 3.57 bays of 5 m: four would be 4.47 m, three are 5.95 m
        count, ok = choose_count(17.86, 5.0, 4.80, 7.5)
        self.assertEqual((count, ok), (3, True))

    def test_exact_multiple(self):
        self.assertEqual(choose_count(20.0, 5.0, 4.80, 7.5), (4, True))

    def test_on_the_minimum_is_still_acceptable(self):
        self.assertEqual(choose_count(14.40, 5.0, 4.80, 7.5), (3, True))

    def test_just_under_the_minimum_rounds_down(self):
        self.assertEqual(choose_count(14.20, 5.0, 4.80, 7.5), (2, True))

    def test_never_collapses_into_one_huge_bay(self):
        # 9.5 m: one bay of 9.5 breaks the maximum, two of 4.75 break the
        # minimum; the size closest to nominal wins and the caller is told
        self.assertEqual(choose_count(9.5, 5.0, 4.80, 7.5), (2, False))

    def test_shorter_than_one_bay(self):
        self.assertEqual(choose_count(3.0, 5.0, 4.80, 7.5), (1, False))


class Planning(unittest.TestCase):

    def test_orientation_follows_the_depth(self):
        self.assertEqual(plan_bays(40.0, 2.5).orientation, PARALLEL)
        self.assertEqual(plan_bays(40.0, 5.0).orientation, PERPENDICULAR)
        self.assertEqual(plan_bays(40.0, 2.05).orientation, PARALLEL)     # -18 %
        self.assertEqual(plan_bays(40.0, 1.9).orientation, AMBIGUOUS)     # too shallow
        self.assertEqual(plan_bays(60.0, 3.5).orientation, AMBIGUOUS)     # in between

    def test_counts(self):
        cases = [
            (40.2, 2.4, 8), (92.4, 5.1, 37), (17.5, 5.0, 7), (17.86, 2.4, 3),
            (17.0, 5.0, 7),    # 2.43 m, just above the 2.40 minimum
            (16.5, 5.0, 6),    # 7 would be 2.36 m, under the minimum
        ]
        for length, depth, expected in cases:
            with self.subTest(length=length, depth=depth):
                self.assertEqual(plan_bays(length, depth).count, expected)

    def test_override_beats_inference(self):
        plan = plan_bays(60.0, 3.5, orientation=PERPENDICULAR)
        self.assertEqual(plan.orientation, PERPENDICULAR)
        self.assertEqual(plan.count, 24)

    def test_warnings(self):
        self.assertTrue(any("curved" in w for w in plan_bays(40.0, 2.4, fit=0.72).warnings))
        self.assertTrue(any("only one bay" in w for w in plan_bays(5.2, 2.5).warnings))
        self.assertTrue(any("instead of the nominal" in w for w in plan_bays(17.86, 2.4).warnings))
        self.assertEqual(plan_bays(20.0, 2.5).warnings, [])


class Axis(unittest.TestCase):

    def test_hull_of_a_square_with_interior_points(self):
        hull = convex_hull([(0, 0), (4, 0), (4, 4), (0, 4), (2, 2), (1, 3)])
        self.assertEqual(len(hull), 4)

    def test_min_width_axis_finds_the_long_side(self):
        for angle in (0, 23, 67, 112, 160):
            with self.subTest(angle=angle):
                shape = strip(40.0, 2.5, angle)
                along, across, length, width, _ = min_width_axis(convex_hull(shape.exterior.coords))
                self.assertAlmostEqual(length, 40.0, places=6)
                self.assertAlmostEqual(width, 2.5, places=6)
                self.assertAlmostEqual(math.degrees(math.atan2(along[1], along[0])) % 180,
                                       angle % 180, places=6)

    def test_strip_axis_is_square_to_the_strip(self):
        for angle in (0, 23, 67, 112):
            with self.subTest(angle=angle):
                cut_points, length, depth, fit = strip_axis(Geom(strip(40.0, 2.5, angle)))
                self.assertAlmostEqual(length, 40.0, places=6)
                self.assertAlmostEqual(depth, 2.5, places=6)
                self.assertAlmostEqual(fit, 1.0, places=6)
                self.assertAlmostEqual(axis_angle_degrees(cut_points) % 180, (angle + 90) % 180, places=6)

    def test_skewed_parallelogram_still_gets_square_bays(self):
        # long sides at 67 degrees, end edges skewed by 28 degrees
        u = (math.cos(math.radians(67)), math.sin(math.radians(67)))
        end = 67 - 90 + 28
        v = (math.cos(math.radians(end)) * 8.5, math.sin(math.radians(end)) * 8.5)
        shape = Polygon([(0, 0), (u[0] * 45, u[1] * 45),
                         (u[0] * 45 + v[0], u[1] * 45 + v[1]), (v[0], v[1])])
        cut_points, length, depth, fit = strip_axis(Geom(shape))
        self.assertAlmostEqual(axis_angle_degrees(cut_points) % 180, 157.0, places=6)
        result = split_into_equal_parts(Geom(shape), 9, axis_angle_degrees(cut_points),
                                        lambda g: g.area())
        for part in result.parts[1:-1]:             # end pieces inherit the skew
            self.assertEqual(edge_angles(part), [67.0, 157.0])

    def test_slanted_ends_do_not_squeeze_the_bays(self):
        # A 15 x 5 m strip whose ends slant 25 degrees: its full extent along
        # the kerb is 17.33 m, but only 15 m of it is usable. Counting over
        # the full extent would give 7 bays and middle bays of 2.14 m.
        shift = 5.0 * math.tan(math.radians(25))
        shape = affinity.rotate(
            Polygon([(0, 0), (15, 0), (15 + shift, 5), (shift, 5)]), 8, origin=(0, 0))
        cut_points, length, depth, fit = strip_axis(Geom(shape))
        self.assertAlmostEqual(length, 15.0, places=6)
        self.assertAlmostEqual(depth, 5.0, places=6)
        plan = plan_bays(length, depth)
        self.assertEqual((plan.orientation, plan.count), (PERPENDICULAR, 6))
        result = split_into_equal_parts(Geom(shape), plan.count,
                                        axis_angle_degrees(cut_points), lambda g: g.area())
        for part in result.parts[1:-1]:            # the middle bays are 2.50 x 5.00 m
            self.assertAlmostEqual(part.area(), 12.5, places=6)
            self.assertEqual(edge_angles(part), [8.0, 98.0])

    def test_measure_callable_is_used_for_sizes(self):
        scale = 111320.0
        shape = affinity.scale(strip(40.0, 2.5, 30), 1 / scale, 1 / scale, origin=(0, 0))
        def metres(a, b):
            return math.hypot(b.x() - a.x(), b.y() - a.y()) * scale
        _, length, depth, _ = strip_axis(Geom(shape), metres)
        self.assertAlmostEqual(length, 40.0, places=6)
        self.assertAlmostEqual(depth, 2.5, places=6)


class GeographicCrs(unittest.TestCase):
    """Why the plugin works in a metric frame for geographic layers."""

    KX = 111320.0 * math.cos(math.radians(52.0))   # metres per degree of longitude
    KY = 110574.0                                   # metres per degree of latitude

    def test_degree_space_skews_the_perpendicular(self):
        rect = strip(17.5, 5.0, 67)
        in_degrees = affinity.affine_transform(rect, [1 / self.KX, 0, 0, 1 / self.KY, 4.5, 52.0])
        cut_points, _, _, _ = strip_axis(Geom(in_degrees))
        deg_angle = axis_angle_degrees(cut_points)
        on_ground = math.degrees(math.atan2(
            math.sin(math.radians(deg_angle)) * self.KY,
            math.cos(math.radians(deg_angle)) * self.KX)) % 180
        self.assertGreater(abs(on_ground - 157.0), 20.0)    # badly off

    def test_metric_frame_restores_the_right_angle(self):
        rect = strip(17.5, 5.0, 67)
        in_degrees = affinity.affine_transform(rect, [1 / self.KX, 0, 0, 1 / self.KY, 4.5, 52.0])
        back = affinity.affine_transform(in_degrees, [self.KX, 0, 0, self.KY, 0, 0])
        cut_points, length, depth, _ = strip_axis(Geom(back))
        self.assertAlmostEqual(axis_angle_degrees(cut_points) % 180, 157.0, places=6)
        self.assertEqual(plan_bays(length, depth).count, 7)


if __name__ == "__main__":
    unittest.main()
