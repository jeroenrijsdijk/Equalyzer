"""Tests for equal_parts.py. Run from the plugin folder:

    python -m unittest discover -s tests -v

Needs shapely for ground truth; QGIS is not needed.
"""

import math
import random
import unittest

from shapely import affinity
from shapely.geometry import MultiPolygon, Polygon, box
from shapely.ops import unary_union

import fake_qgis

fake_qgis.install()

from equal_parts import (  # noqa: E402
    area_below, build_profile, solve_cuts, split_into_equal_parts, width_at,
)
from fake_qgis import Geom, edge_angles  # noqa: E402


def rings_of(shape):
    polys = shape.geoms if isinstance(shape, MultiPolygon) else [shape]
    rings = []
    for p in polys:
        rings.append(list(p.exterior.coords))
        rings.extend(list(h.coords) for h in p.interiors)
    return rings


def circle(radius, segments=400):
    return Polygon([(math.cos(i / segments * 2 * math.pi) * radius,
                     math.sin(i / segments * 2 * math.pi) * radius)
                    for i in range(segments)])


random.seed(7)
SHAPES = {
    "rectangle": box(0, 0, 100, 40),
    "triangle": Polygon([(0, 0), (100, 0), (50, 60)]),
    "L-shape": Polygon([(0, 0), (60, 0), (60, 20), (20, 20), (20, 80), (0, 80)]),
    "U-shape": Polygon([(0, 0), (90, 0), (90, 70), (70, 70), (70, 25),
                        (20, 25), (20, 70), (0, 70)]),
    "donut": Polygon([(0, 0), (100, 0), (100, 100), (0, 100)],
                     [[(30, 30), (70, 30), (70, 70), (30, 70)]]),
    "two islands": MultiPolygon([box(0, 0, 30, 40), box(50, 10, 90, 60)]),
    "T-spike": Polygon([(0, 0), (100, 0), (100, 10), (55, 10), (55, 90),
                        (45, 90), (45, 10), (0, 10)]),
    "blob": unary_union([Polygon([(random.uniform(0, 50), random.uniform(0, 50))
                                  for _ in range(3)]).buffer(6) for _ in range(9)]),
    "400-gon": circle(500),
    "sliver": Polygon([(0, 0), (1000, 0), (1000, 0.5), (0, 2)]),
}


class ProfileMath(unittest.TestCase):
    """build_profile / solve_cuts / area_below against shapely."""

    def test_total_area_matches_shapely(self):
        for name, shape in SHAPES.items():
            with self.subTest(shape=name):
                profile = build_profile(rings_of(shape))
                self.assertAlmostEqual(profile.total, shape.area, delta=shape.area * 1e-12)

    def test_cuts_give_equal_areas(self):
        for name, shape in SHAPES.items():
            for n in (2, 3, 5, 7, 13):
                with self.subTest(shape=name, n=n):
                    profile = build_profile(rings_of(shape))
                    cuts = solve_cuts(profile, [profile.total / n] * n)
                    self.assertEqual(len(cuts), n - 1)
                    self.assertEqual(cuts, sorted(cuts))
                    minx, miny, maxx, maxy = shape.bounds
                    pad = max(maxx - minx, maxy - miny)
                    edges = [miny - pad] + cuts + [maxy + pad]
                    target = shape.area / n
                    for lo, hi in zip(edges, edges[1:]):
                        part = shape.intersection(box(minx - pad, lo, maxx + pad, hi)).area
                        self.assertAlmostEqual(part, target, delta=target * 1e-9)

    def test_area_below_is_the_cumulative_integral(self):
        for name, shape in SHAPES.items():
            with self.subTest(shape=name):
                profile = build_profile(rings_of(shape))
                minx, miny, maxx, maxy = shape.bounds
                pad = max(maxx - minx, maxy - miny)
                for t in (0.1, 0.33, 0.5, 0.77, 0.9):
                    y = miny + (maxy - miny) * t
                    truth = shape.intersection(box(minx - pad, miny - pad, maxx + pad, y)).area
                    self.assertAlmostEqual(area_below(profile, y), truth, delta=shape.area * 1e-9)

    def test_width_is_the_derivative_of_area(self):
        for name, shape in SHAPES.items():
            with self.subTest(shape=name):
                profile = build_profile(rings_of(shape))
                minx, miny, maxx, maxy = shape.bounds
                y = (miny + maxy) / 2
                h = (maxy - miny) * 1e-6
                pad = max(maxx - minx, maxy - miny)
                a1 = shape.intersection(box(minx - pad, miny - pad, maxx + pad, y)).area
                a2 = shape.intersection(box(minx - pad, miny - pad, maxx + pad, y + h)).area
                numeric = (a2 - a1) / h
                self.assertAlmostEqual(width_at(profile, y), numeric, delta=max(numeric, 1) * 1e-4)

    def test_degenerate_input_is_rejected(self):
        with self.assertRaises(ValueError):
            build_profile([[(0, 0), (10, 0), (20, 0)]])
        with self.assertRaises(ValueError):
            build_profile([])


class Pipeline(unittest.TestCase):
    """split_into_equal_parts end to end on the fake geometry."""

    def test_parts_add_up_and_are_equal(self):
        for name, shape in SHAPES.items():
            for angle in (0.0, 17.0, 45.0, 90.0, -33.0, 123.5):
                for n in (2, 3, 5, 8, 17):
                    with self.subTest(shape=name, angle=angle, n=n):
                        result = split_into_equal_parts(Geom(shape), n, angle, lambda g: g.area())
                        self.assertEqual(len(result.parts), n)
                        total = sum(p.area() for p in result.parts)
                        self.assertAlmostEqual(total, shape.area, delta=shape.area * 1e-9)
                        self.assertLess(result.max_deviation, 1e-9)

    def test_rectangle_slices_are_rectangles(self):
        rect = box(0, 0, 40, 2.5)
        for angle in (0, 23, 67, 112):
            with self.subTest(angle=angle):
                shape = affinity.rotate(rect, angle, origin=(0, 0))
                cut = (angle + 90) % 180
                result = split_into_equal_parts(Geom(shape), 8, cut, lambda g: g.area())
                for part in result.parts:
                    self.assertEqual(edge_angles(part), sorted({angle % 180, cut % 180}))
                self.assertEqual(result.disconnected, [])

    def test_concave_shape_reports_disconnected_parts(self):
        # horizontal cuts through the arms of a U leave two pieces per slice;
        # that must be flagged, not hidden
        result = split_into_equal_parts(Geom(SHAPES["U-shape"]), 3, 0.0, lambda g: g.area())
        self.assertTrue(result.disconnected)
        # vertical cuts keep every slice in one piece
        result = split_into_equal_parts(Geom(SHAPES["U-shape"]), 3, 90.0, lambda g: g.area())
        self.assertEqual(result.disconnected, [])

    def test_measured_area_correction_converges(self):
        # pretend the ellipsoid stretches area with latitude, harshly
        def distorted(g):
            s = g.g
            return 0.0 if s.is_empty else s.area * (1.0 + 0.25 * (s.centroid.y / 100.0))
        tall = Polygon([(math.cos(i / 400 * 2 * math.pi) * 500,
                         math.sin(i / 400 * 2 * math.pi) * 500 + 600) for i in range(400)])
        for n in (3, 7, 12):
            with self.subTest(n=n):
                result = split_into_equal_parts(Geom(tall), n, 0.0, distorted)
                measured = [distorted(p) for p in result.parts]
                target = sum(measured) / n
                worst = max(abs(a - target) for a in measured) / target
                self.assertLess(worst, 1e-5)

    def test_correction_never_makes_the_result_worse(self):
        # A measure that wobbles with height fools the Newton step; whatever
        # happens, the result may not be worse than the uncorrected cut.
        def wobbly(g):
            s = g.g
            return 0.0 if s.is_empty else s.area * (1.0 + 0.4 * math.sin(s.centroid.y / 2.0))
        for name in ("rectangle", "triangle", "400-gon", "blob"):
            for n in (3, 7):
                with self.subTest(shape=name, n=n):
                    shape = Geom(SHAPES[name])
                    plain = split_into_equal_parts(shape, n, 0.0, wobbly, max_passes=0)
                    corrected = split_into_equal_parts(shape, n, 0.0, wobbly)
                    self.assertLessEqual(corrected.max_deviation, plain.max_deviation)
                    measured = [wobbly(p) for p in corrected.parts]
                    target = sum(measured) / n
                    actual = max(abs(a - target) for a in measured) / target
                    self.assertAlmostEqual(actual, corrected.max_deviation, places=12)

    def test_single_part_is_the_input(self):
        result = split_into_equal_parts(Geom(SHAPES["rectangle"]), 1, 0.0, lambda g: g.area())
        self.assertEqual(len(result.parts), 1)
        self.assertAlmostEqual(result.parts[0].area(), SHAPES["rectangle"].area)


if __name__ == "__main__":
    unittest.main()
