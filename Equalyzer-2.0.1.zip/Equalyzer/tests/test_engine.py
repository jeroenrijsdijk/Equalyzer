"""Run the real plugin code from polygon_splitter.py against stubbed QGIS.

Covers what the pure tests cannot reach: the engine's wiring, the metric work
frame for layers whose coordinates are not ground metres, editing the source
layer, and the map tools' clean-up. Needs shapely and PyQt6 or PyQt5.
"""

import importlib.util
import unittest

HAVE_QT = any(importlib.util.find_spec(name) for name in ("PyQt6", "PyQt5"))

if HAVE_QT:
    # Imported only when Qt is there; any other import error is a real failure.
    import fake_qgis
    from qgis_stub import (
        Canvas, Feature, Layer, Pt, QgsProject, Qgis, click,
        in_crs, plugin, point_in_crs, strip, to_ground,
    )


def engine_for(mode, features, target, layer=None, direction=None, bay_settings=None):
    layer = layer or Layer("EPSG:28992", features=features)
    da = plugin.make_distance_area(layer, plugin.first_geometry(features))
    direction = direction or [Pt(0, 0), Pt(1, 0)]
    return plugin._SplitEngine(
        layer, features, da, Qgis.AreaUnit.SquareMeters, "m²",
        plugin.crs_area_unit_for(layer), direction, None, mode, target,
        precision=3, bay_settings=bay_settings,
    )


def shapes(parts):
    return {tuple(fake_qgis.edge_angles(p)) for p in parts}


@unittest.skipUnless(HAVE_QT, "PyQt6 or PyQt5 is needed to import polygon_splitter.py")
class EngineWiring(unittest.TestCase):

    def test_count_mode_gives_equal_parts(self):
        engine = engine_for("count", [Feature(1, strip(40, 2.5, 0))], 8,
                            direction=[Pt(0, 0), Pt(0, 1)])
        out = engine.compute_parts_by_feature()
        areas = [p.area() for p in out[0][1]]
        self.assertEqual(len(areas), 8)
        self.assertLess(max(areas) - min(areas), 1e-9)

    def test_bays_batch_with_mixed_orientations(self):
        feats = [Feature(1, strip(40.0, 2.5, 20)),               # parallel -> 8
                 Feature(2, strip(17.5, 5.0, -63, (100, 0))),   # perpendicular -> 7
                 Feature(3, strip(17.86, 2.4, 137, (0, 100)))]  # parallel -> 3
        expect = {1: 8, 2: 7, 3: 3}
        engine = engine_for("bays", feats, 0)
        out = engine.compute_parts_by_feature()
        self.assertEqual(len(out), 3)
        for feature, parts in out:
            with self.subTest(fid=feature.id()):
                self.assertEqual(len(parts), expect[feature.id()])
                areas = [p.area() for p in parts]
                self.assertLess(max(areas) - min(areas), 1e-9)
                self.assertEqual(len(shapes(parts)), 1)          # all the same rectangle
        self.assertEqual(engine.bay_plans[2].orientation, "perpendicular")
        self.assertTrue(any("5.95" in m for m in engine.fallback_messages))

    def test_dust_filter_is_relative_to_the_polygon(self):
        engine = engine_for("count", [Feature(1, strip(0.004, 0.00025, 0))], 4,
                            direction=[Pt(0, 0), Pt(0, 1)])
        self.assertEqual(len(engine.compute_parts_by_feature()[0][1]), 4)

    def test_orientation_override_reaches_the_engine(self):
        engine = engine_for("bays", [Feature(1, strip(60.0, 3.5, 0))], 0,
                            bay_settings={"orientation": "perpendicular"})
        self.assertEqual(len(engine.compute_parts_by_feature()[0][1]), 24)


@unittest.skipUnless(HAVE_QT, "PyQt6 or PyQt5 is needed to import polygon_splitter.py")
class NonMetricLayers(unittest.TestCase):
    """Layers whose coordinates are not ground metres go through a work frame."""

    def setUp(self):
        QgsProject.ellipsoid_setting = "NONE"

    def test_rd_new_is_used_as_it_is(self):
        layer = Layer("EPSG:28992")
        self.assertTrue(plugin.locally_metric(layer, strip(40, 2.5, 0)))
        self.assertEqual(plugin.metric_work_transforms(layer, strip(40, 2.5, 0)), (None, None, None))

    def test_degrees_and_web_mercator_are_not_metric(self):
        for authid in ("EPSG:4326", "EPSG:3857"):
            with self.subTest(crs=authid):
                layer = Layer(authid)
                geom = in_crs(strip(40, 2.5, 30), authid)
                self.assertFalse(plugin.locally_metric(layer, geom))
                self.assertIsNotNone(plugin.metric_work_transforms(layer, geom)[0])

    def test_count_mode_in_degrees_cuts_parallel_to_the_drawn_line(self):
        # A 40 x 2.5 m strip at 67 degrees; the user draws the direction line
        # along its short side, so the parts must be rectangles on the ground.
        ground = strip(40.0, 2.5, 67)
        layer = Layer("EPSG:4326")
        feature = Feature(1, in_crs(ground, "EPSG:4326"))
        short_side = [point_in_crs(0, 0, "EPSG:4326"),
                      point_in_crs(-2.5 * 0.9205, 2.5 * 0.3907, "EPSG:4326")]  # 157 degrees
        engine = engine_for("count", [feature], 8, layer=layer, direction=short_side)
        parts = [to_ground(p, "EPSG:4326") for p in engine.compute_parts_by_feature()[0][1]]
        self.assertEqual(len(parts), 8)
        for part in parts:
            self.assertEqual(fake_qgis.edge_angles(part), [67.0, 157.0])

    def test_bays_in_degrees(self):
        ground = strip(17.5, 5.0, 30)
        layer = Layer("EPSG:4326")
        engine = engine_for("bays", [Feature(1, in_crs(ground, "EPSG:4326"))], 0, layer=layer)
        parts = [to_ground(p, "EPSG:4326") for p in engine.compute_parts_by_feature()[0][1]]
        self.assertEqual(len(parts), 7)
        self.assertEqual(shapes(parts), {(30.0, 120.0)})

    def test_bays_in_web_mercator(self):
        # Mercator "metres" are 1.6 times too long here: without the work frame
        # a 5 m deep strip measures 8.1 m and is recognised as neither kind.
        ground = strip(17.5, 5.0, 30)
        layer = Layer("EPSG:3857")
        engine = engine_for("bays", [Feature(1, in_crs(ground, "EPSG:3857"))], 0, layer=layer)
        parts = engine.compute_parts_by_feature()[0][1]
        self.assertEqual(len(parts), 7)
        self.assertEqual(engine.bay_plans[1].orientation, "perpendicular")

    def test_areas_are_ground_square_metres(self):
        ground = strip(17.5, 5.0, 30)
        for authid in ("EPSG:4326", "EPSG:3857", "EPSG:28992"):
            with self.subTest(crs=authid):
                layer = Layer(authid)
                geom = in_crs(ground, authid)
                da = plugin.make_distance_area(layer, geom)
                self.assertAlmostEqual(da.measureArea(geom), 87.5, places=6)

    def test_project_ellipsoid_is_honoured_for_metric_layers(self):
        QgsProject.ellipsoid_setting = "EPSG:7004"
        da = plugin.make_distance_area(Layer("EPSG:28992"), strip(10, 10, 0))
        self.assertTrue(da.willUseEllipsoid())
        QgsProject.ellipsoid_setting = "NONE"
        da = plugin.make_distance_area(Layer("EPSG:28992"), strip(10, 10, 0))
        self.assertFalse(da.willUseEllipsoid())


@unittest.skipUnless(HAVE_QT, "PyQt6 or PyQt5 is needed to import polygon_splitter.py")
class ReplaceInSourceLayer(unittest.TestCase):

    def setUp(self):
        self.splitter = plugin.PolygonSplitter(plugin.iface)

    def parts_for(self, layer, features):
        return engine_for("bays", features, 0, layer=layer).compute_parts_by_feature()

    def test_bays_replace_the_strip_and_inherit_attributes(self):
        strip_feature = Feature(7, strip(17.5, 5.0, 0), attrs=["P-zone", 42])
        layer = Layer("EPSG:28992", wkb_type=3, features=[strip_feature], editable=True)
        ok, switched_on, replaced, written = self.splitter._replace_in_source_layer(
            layer, self.parts_for(layer, [strip_feature]))
        self.assertTrue(ok)
        self.assertFalse(switched_on)
        self.assertEqual((replaced, written), (1, 7))
        self.assertNotIn(7, layer.features)
        self.assertEqual(len(layer.features), 7)
        for f in layer.features.values():
            self.assertEqual(f.geometry().g.geom_type, "Polygon")   # fitted to a Polygon layer
            self.assertEqual((f.attribute(0), f.attribute(1)), ("P-zone", 42))
        self.assertEqual(layer.log, ["begin", "add 7", "delete [7]", "end"])

    def test_never_saves_behind_the_users_back(self):
        strip_feature = Feature(7, strip(17.5, 5.0, 0), attrs=["x"])
        layer = Layer("EPSG:28992", features=[strip_feature], editable=False)
        ok, switched_on, _, _ = self.splitter._replace_in_source_layer(
            layer, self.parts_for(layer, [strip_feature]))
        self.assertTrue(ok)
        self.assertTrue(switched_on)
        self.assertTrue(layer.editable)
        self.assertNotIn("commit", layer.log)

    def test_a_refused_edit_is_taken_back_completely(self):
        strip_feature = Feature(7, strip(17.5, 5.0, 0), attrs=["x"])
        layer = Layer("EPSG:28992", features=[strip_feature], editable=True, accept_adds=False)
        ok, message, _, _ = self.splitter._replace_in_source_layer(
            layer, self.parts_for(layer, [strip_feature]))
        self.assertFalse(ok)
        self.assertIn("destroy", layer.log)
        self.assertNotIn("end", layer.log)
        self.assertEqual(list(layer.features), [7])                  # as before

    def test_a_single_bay_strip_is_left_alone(self):
        single = Feature(7, strip(5.0, 2.5, 0), attrs=["x"])
        double = Feature(8, strip(10.0, 2.5, 0, (0, 20)), attrs=["y"])
        layer = Layer("EPSG:28992", features=[single, double], editable=True)
        ok, _, replaced, written = self.splitter._replace_in_source_layer(
            layer, self.parts_for(layer, [single, double]))
        self.assertTrue(ok)
        self.assertEqual((replaced, written), (1, 2))
        self.assertIn(7, layer.features)


@unittest.skipUnless(HAVE_QT, "PyQt6 or PyQt5 is needed to import polygon_splitter.py")
class MapTools(unittest.TestCase):

    def test_line_tool_hands_back_the_previous_tool_and_snapping(self):
        previous = object()
        canvas = Canvas(previous_tool=previous)
        before = dict(canvas.snapping.cfg.state)
        received = []
        tool = plugin.LineDrawTool(canvas, received.append)
        canvas.setMapTool(tool)
        self.assertTrue(canvas.snapping.cfg.state["enabled"])        # snapping on while drawing
        tool.canvasReleaseEvent(click(Pt(0, 0)))
        tool.canvasReleaseEvent(click(Pt(3, 4)))
        self.assertEqual(len(received[0]), 2)
        self.assertIs(canvas.mapTool(), previous)
        self.assertEqual(canvas.snapping.cfg.state, before)

    def test_escape_also_restores(self):
        previous = object()
        canvas = Canvas(previous_tool=previous)
        received = []
        tool = plugin.LineDrawTool(canvas, received.append)
        canvas.setMapTool(tool)
        tool.canvasReleaseEvent(click(Pt(0, 0), right=True))
        self.assertEqual(received, [None])
        self.assertIs(canvas.mapTool(), previous)

    def test_without_a_previous_tool_the_canvas_is_left_empty(self):
        canvas = Canvas(previous_tool=None)
        tool = plugin.PointSelectTool(canvas, lambda p: None)
        canvas.setMapTool(tool)
        tool.canvasReleaseEvent(click(Pt(1, 1)))
        self.assertIsNone(canvas.mapTool())


@unittest.skipUnless(HAVE_QT, "PyQt6 or PyQt5 is needed to import polygon_splitter.py")
class Picking(unittest.TestCase):

    def test_longest_crossing_wins(self):
        a = Feature(1, strip(20, 5, 0))
        b = Feature(2, strip(20, 5, 0, (0, 6)))
        layer = Layer("EPSG:28992", features=[a, b])
        # crosses a over 5 m and only clips b's corner
        line = [Pt(10, -1), Pt(10.5, 7)]
        self.assertEqual(plugin.pick_feature_under_line(layer, line).id(), 1)

    def test_line_beside_everything_falls_back_to_the_first_click(self):
        a = Feature(1, strip(20, 5, 0))
        layer = Layer("EPSG:28992", features=[a])
        self.assertIsNone(plugin.pick_feature_under_line(layer, [Pt(30, 30), Pt(40, 40)]))
        self.assertEqual(plugin.pick_feature_under_line(layer, [Pt(2, 2), Pt(2, 2.0001)]).id(), 1)


if __name__ == "__main__":
    unittest.main()
